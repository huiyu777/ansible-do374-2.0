# fix screenshield timeout (sh)
[[ -n "${DISPLAY}" && -x /bin/gsettings ]] &&
gsettings set org.gnome.desktop.session idle-delay 0
